"use client";
import { useForm, Controller } from "react-hook-form";
import { useRouter } from "next/navigation";

const RegistrationForm = () => {
  const {
    control,
    handleSubmit,
    setError,
    register,
    formState: { errors },
  } = useForm();

  const router = useRouter();

  const onSubmit = (data) => {
    const {
      name,
      email,
      password,
      confirmPassword,
      experience,
      github,
      linkedin,
      portfolio,
    } = data;

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setError("email", { type: "manual", message: "Invalid email address" });
      return;
    }

    if (name.length < 4) {
      setError("name", {
        type: "manual",
        message: "Name must be at least 4 characters",
      });
      return;
    }

    if (password.length < 8 || !/[A-Z]/.test(password)) {
      setError("password", {
        type: "manual",
        message:
          "Password must be 8 characters and contain at least 1 uppercase letter",
      });
      return;
    }

    if (password !== confirmPassword) {
      setError("confirmPassword", {
        type: "manual",
        message: "Passwords do not match",
      });
      return;
    }

    if (!gender) {
      setError("gender", { type: "manual", message: "Gender is required" });
      return;
    }

    if (isNaN(experience) || experience < 0) {
      setError("experience", {
        type: "manual",
        message: "Invalid years of experience",
      });
      return;
    }

    const githubRegex = /^(https?:\/\/)?(www\.)?github\.com\/[\w-]+(\/)?$/;
    if (!githubRegex.test(github)) {
      setError("github", { type: "manual", message: "Invalid GitHub link" });
      return;
    }

    const linkedinRegex = /^(https?:\/\/)?(www\.)?linkedin\.com\/.*$/;
    if (!linkedinRegex.test(linkedin)) {
      setError("linkedin", {
        type: "manual",
        message: "Invalid LinkedIn link",
      });
      return;
    }

    if (portfolio.length < 5) {
      setError("portfolio", {
        type: "manual",
        message: "Invalid Portfolio link",
      });
      return;
    }

    // else..............
    // If all validation passes, navigate to the success page
    router.push("/success");
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="max-w-md mx-auto mt-8">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Name
        </label>
        <Controller
          name="name"
          control={control} // baki ase
          rules={{
            required: "Name is required",
            minLength: {
              value: 4,
              message: "Name must be at least 4 characters",
            },
          }}
          render={({ field }) => {
            return (
              <>
                <input
                  {...field}
                  type="text"
                  placeholder="Enter your name"
                  className="p-2 border border-gray-300 w-full"
                />
              </>
            );
          }}
        />
        {errors.name && (
          <span className="text-red-500 text-sm">{errors.name.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Email
        </label>
        <Controller
          name="email"
          control={control}
          rules={{ required: "Email is required" }}
          render={({ field }) => (
            <input
              {...field}
              type="email"
              placeholder="Enter your email"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.email && (
          <span className="text-red-500 text-sm">{errors.email.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Password
        </label>
        <Controller
          name="password"
          control={control}
          rules={{ required: "Password is required" }}
          render={({ field }) => (
            <input
              {...field}
              type="password"
              placeholder="Enter your password"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.password && (
          <span className="text-red-500 text-sm">
            {errors.password.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Confirm Password
        </label>
        <Controller
          name="confirmPassword"
          control={control}
          rules={{ required: "Confirm Password is required" }}
          render={({ field }) => (
            <input
              {...field}
              type="password"
              placeholder="Confirm your password"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.confirmPassword && (
          <span className="text-red-500 text-sm">
            {errors.confirmPassword.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Years of Experience
        </label>
        <Controller
          name="experience"
          control={control}
          rules={{
            required: "Years of Experience is required",
            pattern: { value: /^[0-9]+$/, message: "Invalid input" },
          }}
          render={({ field }) => (
            <input
              {...field}
              type="text"
              placeholder="Enter your years of experience"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.experience && (
          <span className="text-red-500 text-sm">
            {errors.experience.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Gender
        </label>
        <div>
          <label className="mr-4">
            <input
              type="radio"
              value="male"
              {...register("gender", { required: "Gender is required" })}
            />{" "}
            Male
          </label>
          <label>
            <input
              type="radio"
              value="female"
              {...register("gender", { required: "Gender is required" })}
            />{" "}
            Female
          </label>
        </div>
        {errors.gender && (
          <span className="text-red-500 text-sm">{errors.gender.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          GitHub Link
        </label>
        <Controller
          name="github"
          control={control}
          rules={{
            required: "GitHub Link is required",
            pattern: {
              value: /^(https?:\/\/)?(www\.)?github\.com\/[\w-]+(\/)?$/,
              message: "Invalid GitHub link",
            },
          }}
          render={({ field }) => (
            <input
              {...field}
              type="text"
              placeholder="Enter your GitHub link"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.github && (
          <span className="text-red-500 text-sm">{errors.github.message}</span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          LinkedIn Link
        </label>
        <Controller
          name="linkedin"
          control={control}
          rules={{
            required: "LinkedIn Link is required",
            pattern: {
              value: /^(https?:\/\/)?(www\.)?linkedin\.com\/.*$/,
              message: "Invalid LinkedIn link",
            },
          }}
          render={({ field }) => (
            <input
              {...field}
              type="text"
              placeholder="Enter your LinkedIn link"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.linkedin && (
          <span className="text-red-500 text-sm">
            {errors.linkedin.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Portfolio Link
        </label>
        <Controller
          name="portfolio"
          control={control}
          rules={{
            required: "Portfolio Link is required",
            pattern: {
              value: /^(https?:\/\/)?(www\.)?.*$/,
              message: "Invalid Portfolio link",
            },
          }}
          render={({ field }) => (
            <input
              {...field}
              type="text"
              placeholder="Enter your Portfolio link"
              className="p-2 border border-gray-300 w-full"
            />
          )}
        />
        {errors.portfolio && (
          <span className="text-red-500 text-sm">
            {errors.portfolio.message}
          </span>
        )}
      </div>

      <div className="mb-4">
        <button
          type="submit"
          className="bg-blue-500 text-white py-2 px-4 rounded"
        >
          Submit
        </button>
      </div>
    </form>
  );
};

export default RegistrationForm;
