const Success = () => {
  return (
    <div>
      <h1>Hello Success page!</h1>
    </div>
  );
};

export default Success;
